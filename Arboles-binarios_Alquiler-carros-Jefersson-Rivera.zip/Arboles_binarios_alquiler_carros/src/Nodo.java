import java.util.Scanner;

public class Nodo {
	public int valor;
	public Nodo izq;
	public Nodo der;

	public Nodo (int  _valor) {
	this.valor = _valor;
	this.izq = null;
	this.der = null;
	}
	}
