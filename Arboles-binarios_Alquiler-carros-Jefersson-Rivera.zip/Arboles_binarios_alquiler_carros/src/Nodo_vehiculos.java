import java.util.Scanner;

class Nodo_vehiculos {


public int valor;
public Nodo_vehiculos izq;
public Nodo_vehiculos der;

public Nodo_vehiculos (int  _valor) {
this.valor = _valor;
this.izq = null;
this.der = null;
}
}
